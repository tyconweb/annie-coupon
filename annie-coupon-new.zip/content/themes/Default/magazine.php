<div role="main">
   <div class="page-dashboard-home">
      <!-- <div class="carousel carousel_for_posts-index js-carousel" data-component-ready="">
         <div class="carousel__slides js-carousel__slides">
            <a href="#" class="carousel__slide js-carousel__slide" data-horizontal-scroll-slide-id="item_3">
               <div class="carousel__slide-background lazyloaded" data-bg="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" style="background-image: url(&quot;https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat&quot;);"></div>
               <div class="carousel__slide-image">
                  <picture>
                     <source data-srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 1200px)" srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 992px)" srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 768px)" srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 576px)" srcset="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <img class="carousel__slide-image-img ls-is-cached lazyloaded" alt="Nagellack entsorgen: So machst du es richtig" data-src="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" src="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <noscript><img src="https://img-01.gutscheinpony.de/img/4f/50/a4/nagllack_oliv_sonnengelb.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" class="carousel__slide-image-img" alt="Nagellack entsorgen: So machst du es richtig"/></noscript>
                  </picture>
               </div>
               <div class="carousel__content">
                  <div class="container">
                     <div class="carousel__content-title">
                        Dispose of nail polish: Here's how to do it right                                
                     </div>
                     <div class="carousel__content-excerpt">
                        <p>If you wipe your bathroom cabinets with a damp cloth during spring cleaning and want to get rid of old dust collectors, you will certainly also have to dispose of old nail polish. But before you throw the bottles in the household waste, do you hear quiet alarm bells? There was something to consider when disposing of old paints and varnishes! Find out here how you can dispose of old nail polish in an environmentally friendly and legally compliant manner.Dispose of nail polish: How to do it right</p>
                     </div>
                     <div class="posts-meta carousel__content-meta posts-meta_color_white posts-meta_size_compact">
                        <div class="posts-meta__published">
                           <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text">3. Februar 2022</span>    
                        </div>
                        <div class="posts-meta__details">
                           <span class="posts-meta__details-author">Nina</span> in <span class="posts-meta__details-category">Lifestyle</span>    
                        </div>
                     </div>
                     <div class="carousel__content-controls">
                        <span class="btn carousel__content-btn">
                        Continue Reading                                    </span>
                     </div>
                  </div>
               </div>
            </a>
            <a href="#" class="carousel__slide js-carousel__slide" data-horizontal-scroll-slide-id="item_4">
               <div class="carousel__slide-background lazyloaded" data-bg="" style="background-image: url(&quot;https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat&quot;);"></div>
               <div class="carousel__slide-image">
                  <picture>
                     <source data-srcset="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 1200px)">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 992px)">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 768px)">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 576px)">
                     <img class="carousel__slide-image-img lazyload" alt="Kresse anpflanzen: So gelingt das Superfood von der Fensterbank" data-src="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <noscript><img src="https://img-01.gutscheinpony.de/img/fc/db/7f/Kresse_gesund-essen.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" class="carousel__slide-image-img" alt="Kresse anpflanzen: So gelingt das Superfood von der Fensterbank"/></noscript>
                  </picture>
               </div>
               <div class="carousel__content">
                  <div class="container">
                     <div class="carousel__content-title">
                        Plant cress: This is how the superfood from the windowsill succeeds                             
                     </div>
                     <div class="carousel__content-excerpt">
                        <p>When we talk about “superfoods”, you probably think of foods like chia seeds, goji berries, turmeric, quinoa or avocados. The green miracle of nature "cress" contains tons of good nutrients. You should definitely integrate the herb into your diet plan. Here you can find out how you can grow the superfood “zero km” and “plastic-free” on your own windowsill.</p>
                     </div>
                     <div class="posts-meta carousel__content-meta posts-meta_color_white posts-meta_size_compact">
                        <div class="posts-meta__published">
                           <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text">27. Januar 2022</span>    
                        </div>
                        <div class="posts-meta__details">
                           <span class="posts-meta__details-author">Nina</span> in <span class="posts-meta__details-category">At home</span>    
                        </div>
                     </div>
                     <div class="carousel__content-controls">
                        <span class="btn carousel__content-btn">
                        Continue reading                                    </span>
                     </div>
                  </div>
               </div>
            </a>
            <a href="#" class="carousel__slide js-carousel__slide" data-horizontal-scroll-slide-id="item_0">
               <div class="carousel__slide-background lazyloaded" data-bg="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" style="background-image: url(&quot;https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat&quot;);"></div>
               <div class="carousel__slide-image">
                  <picture>
                     <source data-srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 1200px)" srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 992px)" srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 768px)" srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 576px)" srcset="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <img class="carousel__slide-image-img ls-is-cached lazyloaded" alt="Black Friday Rabatte 2022 - Diese Gutscheine solltest du nicht verpassen" data-src="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" src="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <noscript><img src="https://img-01.gutscheinpony.de/img/9b/ac/53/blackfridayrabattetitel.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" class="carousel__slide-image-img" alt="Black Friday Rabatte 2022 - Diese Gutscheine solltest du nicht verpassen"/></noscript>
                  </picture>
               </div>
               <div class="carousel__content">
                  <div class="container">
                     <div class="carousel__content-title">
                        Black Friday discounts 2022 - You should not miss these coupons                                
                     </div>
                     <div class="carousel__content-excerpt">
                        <p>Black Week is in full swing, culminating on Friday. Some great Black Friday discounts 2022 are already recommended. Here you will find an overview of the top promotions that you should take advantage of today and get a foretaste of the further price reductions next weekend. Find out what to look out for when bargain hunting, how to prepare for it and what Black Friday is actually all about.</p>
                     </div>
                     <div class="posts-meta carousel__content-meta posts-meta_color_white posts-meta_size_compact">
                        <div class="posts-meta__published">
                           <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text">23. November 2022</span>    
                        </div>
                        <div class="posts-meta__details">
                           <span class="posts-meta__details-author">Alina</span> in <span class="posts-meta__details-category">Shopping Hacks</span>    
                        </div>
                     </div>
                     <div class="carousel__content-controls">
                        <span class="btn carousel__content-btn">
                        Continue reading                                    </span>
                     </div>
                  </div>
               </div>
            </a>
            <a href="#" class="carousel__slide js-carousel__slide" data-horizontal-scroll-slide-id="item_1">
               <div class="carousel__slide-background lazyloaded" data-bg="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" style="background-image: url(&quot;https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat&quot;);"></div>
               <div class="carousel__slide-image">
                  <picture>
                     <source data-srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 1200px)" srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 992px)" srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 768px)" srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 576px)" srcset="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <img class="carousel__slide-image-img ls-is-cached lazyloaded" alt="Singles Day Angebote 2022 - Die besten Gutscheine und Rabatte" data-src="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" src="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <noscript><img src="https://img-01.gutscheinpony.de/img/e8/3b/7d/singles-day-angebote.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" class="carousel__slide-image-img" alt="Singles Day Angebote 2022 - Die besten Gutscheine und Rabatte"/></noscript>
                  </picture>
               </div>
               <div class="carousel__content">
                  <div class="container">
                     <div class="carousel__content-title">
                        Singles Day Deals 2022 - Best Coupons and Discounts                              
                     </div>
                     <div class="carousel__content-excerpt">
                        <p>Singles Day offers in Germany are nowhere near as eagerly awaited as Black Friday bargains. Strange, after all, it is the world's highest-selling day of the year. Find all discounts and savings tips for the international shopping event here!</p>
                     </div>
                     <div class="posts-meta carousel__content-meta posts-meta_color_white posts-meta_size_compact">
                        <div class="posts-meta__published">
                           <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text">11. November 2022</span>    
                        </div>
                        <div class="posts-meta__details">
                           <span class="posts-meta__details-author">Alina</span> in <span class="posts-meta__details-category">Shopping Hacks</span>    
                        </div>
                     </div>
                     <div class="carousel__content-controls">
                        <span class="btn carousel__content-btn">
                        Continue reading                                    </span>
                     </div>
                  </div>
               </div>
            </a>
            <a href="#" class="carousel__slide js-carousel__slide" data-horizontal-scroll-slide-id="item_2">
               <div class="carousel__slide-background lazyloaded" data-bg="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" style="background-image: url(&quot;https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1920&amp;h=450&amp;q=70&amp;auto=compress%2Cformat&quot;);"></div>
               <div class="carousel__slide-image">
                  <picture>
                     <source data-srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 1200px)" srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1440&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 992px)" srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=1200&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 768px)" srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=992&amp;h=450&amp;q=70&amp;auto=compress%2Cformat">
                     <source data-srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" media="(min-width: 576px)" srcset="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=768&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <img class="carousel__slide-image-img lazyloaded" alt="Kalte Hände: Ursachen und schnelle Hilfe" data-src="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" src="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat">
                     <noscript><img src="https://img-01.gutscheinpony.de/img/ad/35/e2/Kalte_Hnde_wrmen.jpg?fit=crop&amp;w=576&amp;h=430&amp;q=70&amp;auto=compress%2Cformat" class="carousel__slide-image-img" alt="Kalte Hände: Ursachen und schnelle Hilfe"/></noscript>
                  </picture>
               </div>
               <div class="carousel__content">
                  <div class="container">
                     <div class="carousel__content-title">
                        Cold hands: causes and quick help                            
                     </div>
                     <div class="carousel__content-excerpt">
                        <p>Cold hands are something completely natural in winter, because the body first supplies your brain and internal organs with energy when it is cold. Unfortunately, your nose, ears, hands and feet are left behind. But do you often have cold hands regardless of the outside temperature? Find out more about possible causes here.</p>
                     </div>
                     <div class="posts-meta carousel__content-meta posts-meta_color_white posts-meta_size_compact">
                        <div class="posts-meta__published">
                           <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text">11. Februar 2022</span>    
                        </div>
                        <div class="posts-meta__details">
                           <span class="posts-meta__details-author">Nina</span> in <span class="posts-meta__details-category">Lifestyle</span>    
                        </div>
                     </div>
                     <div class="carousel__content-controls">
                        <span class="btn carousel__content-btn">
                        Continue reading                                    </span>
                     </div>
                  </div>
               </div>
            </a>
         </div>
         <div class="carousel__layout-breadcrumb">
            <div class="container">
               <script type="application/ld+json">{"@context":"https:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"@type":"Thing","@id":"https:\/\/www.gutscheinpony.de\/","name":"Home"}},{"@type":"ListItem","position":2,"item":{"@type":"Thing","@id":"https:\/\/www.gutscheinpony.de\/angesagt","name":"Magazin"}}]}</script>
               <ol class="layout-breadcrumb layout-breadcrumb_is-teaser">
                  <li class="layout-breadcrumb__item layout-breadcrumb__item_is-previous">
                     <a href="/">Home</a>            
                  </li>
                  <li class="layout-breadcrumb__item active">
                     Magazine            
                  </li>
               </ol>
            </div>
         </div>
         <div class="carousel__navigation-button carousel__navigation-button_type_prev js-carousel__navigation-button active" role="button">
            <span class="carousel__navigation-icon" aria-hidden="true"></span>
            <span class="sr-only">Return</span>
         </div>
         <div class="carousel__navigation-button carousel__navigation-button_type_next js-carousel__navigation-button active" role="button">
            <span class="carousel__navigation-icon" aria-hidden="true"></span>
            <span class="sr-only">Before</span>
         </div>
         <div class="carousel__indicators-list js-carousel__indicators-list"><span class="carousel__indicator" slideid="item_0"></span><span class="carousel__indicator" slideid="item_1"></span><span class="carousel__indicator" slideid="item_2"></span><span class="carousel__indicator active" slideid="item_3"></span><span class="carousel__indicator" slideid="item_4"></span></div>
      </div> -->
      <div class="container">
         <div class="page-dashboard-home__section">
            <div class="page-header">
            </div>
         </div>
      </div>
      <div class="container">
         <div class="page-dashboard-home__section-posts">
            <div class="page-header">
               <h1 style=" text-align: center;" class="page-header__headline">
                  Magazine
               </h1>
            </div>
            <?php
               $category = '';
               $cond = '';
               $limit = 6;
               if (isset($_GET['category'])) {
                  $category = $_GET['category'];
                  $cond = ($category!='') ? "WHERE section_name = '$category'" : "";
               }
               if (isset($_GET['limit'])) {
                  $limit = 999999;
               }
            ?>
            <div class="post-categories-tabber js-post-categories-tabber" data-component-ready="">
               <a href="?category=" class="post-categories-tabber__link js-post-categories-tabber__link <?= $category=='' ? 'active' : '' ?>">
               All      </a>
               <a href="?category=LIFESTYLE" class="post-categories-tabber__link js-post-categories-tabber__link <?= $category=='LIFESTYLE' ? 'active' : '' ?>">Lifestyle</a><a href="?category=SHOPPING HACKS" class="post-categories-tabber__link js-post-categories-tabber__link <?= $category=='SHOPPING HACKS' ? 'active' : '' ?>">Shopping Hacks</a><a href="?category=VACATION & LEISURE TIME" class="post-categories-tabber__link js-post-categories-tabber__link <?= $category=='VACATION & LEISURE TIME' ? 'active' : '' ?>">Vacation &amp; Leisure time</a><a href="?category=AT HOME" class="post-categories-tabber__link js-post-categories-tabber__link <?= $category=='AT HOME' ? 'active' : '' ?>">At home</a>    
            </div>
            <br>
            <div class="page-list">
               <div class="row">
                  <?php
                     require 'includes/site/db.php';
                     $query = "SELECT * FROM blogs $cond LIMIT 6";
                     // print_r($query); exit;
                     $query_run = mysqli_query($db, $query);
                     $checkIfExist = mysqli_num_rows($query_run) > 0;
                     if ($checkIfExist)
                     {
                     while($row = mysqli_fetch_array($query_run))
                     {
                     ?>
                  <div class="col-12 col-md-6 col-lg-4 ">
                     <div id="post-2901" class="posts-list-item-primary page-list__item">
                        <a href="/magazine-single?id=<?= $row['id'] ?>" class="posts-list-item-primary__image-link">
                           <div class="posts-list-item-primary__image-wrapper">
                              <picture>
                                 <img class="img-fluid posts-list-item-primary__image image-grayscale lazyload" title="<?= $row['title'] ?>" alt="<?= $row['title'] ?>" data-src="<?= $row['image'] ?>">
                                 <noscript><img src="<?= $row['image'] ?>" class="img-fluid posts-list-item-primary__image image-grayscale" title="<?= $row['title'] ?>" alt="<?= $row['title'] ?>"/></noscript>
                              </picture>
                           </div>
                        </a>
                        <div class="posts-list-item-primary__content">
                           <div class="posts-meta posts-list-item-primary__meta">
                              <div class="posts-meta__published">
                                 <i class="posts-meta__published-icon fa fa-clock"></i>&nbsp;<span class="posts-meta__published-text"> <?php echo $row['created']; ?> </span>
                              </div>
                              <div class="posts-meta__details">
                                 <span class="posts-meta__details-author"><?= $row['display_name'] ?></span> in <a href="?category=<?= $row['section_name']; ?>" class="posts-meta__details-category"> <?php echo $row['section_name']; ?> </a>
                              </div>
                           </div>
                           <a href="/magazine-single?id=<?= $row['id'] ?>" class="posts-list-item-primary__title" title="<?= $row['title'] ?>"> <?php echo $row['title']; ?> </a>
                           <div class="posts-list-item-primary__excerpt">
                              <p> <?php echo $row['short_description']; ?> </p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php
                     }
                     }
                     else
                     {
                     echo "No Record Found";
                     }
                     ?>
               </div>
            </div>
            <div class="load-more">
               <a href="?limit=all" class="btn btn_outlined load-more__button">More articles</a>
            </div>
         </div>
      </div>
   </div>
   <div class="scroll-up-button js-scroll-up-button" data-button-label="Nach oben scrollen" data-component-ready=""></div>
</div>