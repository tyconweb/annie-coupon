<!DOCTYPE html>

<html>

<head>
<?php echo add_admin_head(); ?>
</head>

<body>

<div id="wrap">